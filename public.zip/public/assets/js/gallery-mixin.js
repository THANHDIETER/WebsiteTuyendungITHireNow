const range = [...Array(15).keys()];

console.log(range); // Output: [0, 1, 2, ..., 14]